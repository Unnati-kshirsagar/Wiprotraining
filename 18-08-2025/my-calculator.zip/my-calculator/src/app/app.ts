import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Calculator } from './calculator/calculator';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, Calculator],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  myMessage = 'Welcome to My Angular App!';
}

export { AppComponent as App };
